package test.model.facility;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import main.model.facility.Building;

public class BuildingTest {
	
	
	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testGetInfo() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetScheduleManager() {
		fail("Not yet implemented");
	}

	@Test
	public void testListFacilities() {
		fail("Not yet implemented");
	}

	@Test
	public void testRequestAvailableCapacity() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetFacilityInformation() {
		fail("Not yet implemented");
	}

	@Test
	public void testAddNewFacility() {
		fail("Not yet implemented");
	}

	@Test
	public void testAddNewFacilityDetail() {
		fail("Not yet implemented");
	}

	@Test
	public void testRemoveFacility() {
		fail("Not yet implemented");
	}

}
