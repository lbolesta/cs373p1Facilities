package test.model.facility;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ScheduleManagerTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testGetMaint() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetMaint() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetUsage() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetUsage() {
		fail("Not yet implemented");
	}

	@Test
	public void testMakeFacilityMaintRequest() {
		fail("Not yet implemented");
	}

	@Test
	public void testScheduleMaintenance() {
		fail("Not yet implemented");
	}

	@Test
	public void testCalcMaintenanceCostForFacility() {
		fail("Not yet implemented");
	}

	@Test
	public void testCalcProblemRateForFacility() {
		fail("Not yet implemented");
	}

	@Test
	public void testCalcDownTimeForFacility() {
		fail("Not yet implemented");
	}

	@Test
	public void testListMaintRequests() {
		fail("Not yet implemented");
	}

	@Test
	public void testListMaintenance() {
		fail("Not yet implemented");
	}

	@Test
	public void testListFacilityProblems() {
		fail("Not yet implemented");
	}

	@Test
	public void testIsInUseDuringInterval() {
		fail("Not yet implemented");
	}

	@Test
	public void testAssignFacilityToUse() {
		fail("Not yet implemented");
	}

	@Test
	public void testVacateFacility() {
		fail("Not yet implemented");
	}

	@Test
	public void testListInspections() {
		fail("Not yet implemented");
	}

	@Test
	public void testListActualUsage() {
		fail("Not yet implemented");
	}

	@Test
	public void testCalcUsageRate() {
		fail("Not yet implemented");
	}

	@Test
	public void testIsUnderMaintenance() {
		fail("Not yet implemented");
	}

}
