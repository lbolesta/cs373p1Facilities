package test.model.use;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class UsageServiceTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testIsInUseDuringInterval() {
		fail("Not yet implemented");
	}

	@Test
	public void testAssignFacilityToUse() {
		fail("Not yet implemented");
	}

	@Test
	public void testVacateFacility() {
		fail("Not yet implemented");
	}

	@Test
	public void testListInspections() {
		fail("Not yet implemented");
	}

	@Test
	public void testListActualUsage() {
		fail("Not yet implemented");
	}

	@Test
	public void testCalcUsageRate() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetReservations() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetReservations() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetInspections() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetInspections() {
		fail("Not yet implemented");
	}

}
